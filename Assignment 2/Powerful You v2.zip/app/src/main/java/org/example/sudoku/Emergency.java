package org.example.sudoku;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;


public class Emergency extends Activity implements View.OnClickListener {

    private static final String TAG = "emergency";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.emergency);
        View emergencys = findViewById(R.id.emergencystatistics);
        emergencys.setOnClickListener(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.emergencystatistics:
                Intent statsInt = new Intent(this, EmergencyStats.class);
                startActivity(statsInt);
                Log.d(TAG, "clicked on Emergency Statistics");
                break;
        }
    }

    //EMERGENCY STATS BUTTON ACT
    public void emergencystatistics(View view){
        Intent intent = new Intent(this, EmergencyStats.class);
        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
