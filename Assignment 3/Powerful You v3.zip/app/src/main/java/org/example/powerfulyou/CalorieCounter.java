package org.example.powerfulyou;

import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.DragShadowBuilder;
import android.view.View.OnDragListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.app.Activity;
import android.widget.TextView;

import org.example.sudoku.R;

/**
 * Created by Dita on 7/13/2015.
 */
public class CalorieCounter extends Activity implements OnTouchListener, OnDragListener{

    ImageView health, strength, emergency;
    TextView counter;
    int caltotal;
    Food h,s,e;
    RelativeLayout top_container;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.caloriecounter);

        health = (ImageView)findViewById(R.id.healthicon);
        health.setOnTouchListener(this);
        strength = (ImageView)findViewById(R.id.strengthicon);
        strength.setOnTouchListener(this);
        emergency = (ImageView)findViewById(R.id.emergencyicon);
        emergency.setOnTouchListener(this);

        counter = (TextView)findViewById(R.id.counter);


        h = new Food(health, 30, "Health");
        s = new Food(strength, 300, "Strength");
        e = new Food(emergency, 60, "Emergency");

        h.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.icecream));
        s.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.apple));
        e.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.blueberries));



        h.setOnTouchListener(this);
        s.setOnTouchListener(this);
        e.setOnTouchListener(this);

        findViewById(R.id.top_container).setOnDragListener(this);
        findViewById(R.id.bottom_container).setOnDragListener(this);

        top_container = (RelativeLayout)findViewById(R.id.top_container);
        top_container.addView(h);
        top_container.addView(s);
        top_container.addView(e);
    }

    @Override
    public boolean onTouch(View v, MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(v);
            v.startDrag(null, shadowBuilder, v, 0);
            v.setVisibility(View.INVISIBLE);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean onDrag(View v, DragEvent e) {
        if (e.getAction()==DragEvent.ACTION_DROP) {
            View view = (View) e.getLocalState();
            ViewGroup from = (ViewGroup) view.getParent();
            from.removeView(view);
            RelativeLayout to = (RelativeLayout) v;
            to.addView(view);
            view.setVisibility(View.VISIBLE);
            //Food f = (Food)v;
            //caltotal+=f.getCal();
        }
        return true;
    }



}