package org.example.powerfulyou;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;

/**
 * Created by Dita on 7/13/2015.
 */
public class Food extends ImageView{


    private int cal;
    private String name;

    public Food(Context c, AttributeSet attrs){
        super(c,attrs);
    }

    public Food(Context context, int c, String n){
        super(context);
        cal = c;
        name = n;
    }

    public Food(ImageView mv, int c, String n){
        super(mv.getContext());
        cal = c;
        name = n;

    }

    public int getCal() { return cal; }

    public String getName(){ return name; }


}
